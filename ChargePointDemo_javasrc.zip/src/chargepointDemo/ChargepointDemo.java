package chargepointDemo;
/*
 * ChargePoint demo Game of Life
 * 
 * The game is played on a rectangular grid of cells. A cell
 * can be live or dead. An initial pattern of live cells is
 * zapped on the board, and then the game proceeds time tick 
 * by time tick. Moves are made by rules, not by any players.
 * In that sense, the game is deterministic.
 * 
 * To support this game, we use
 * - GameOfLife class. It instantiates game board, runs the
 * ticks, and shows the board
 * - Grid class. Over ticks, the pattern changes and so does 
 * the grid size necessary to hold the pattern. We have 
 * implemented an infinite grid. (other choices in grid design 
 * such as endless, fixed, etc.) 
 * - GridCell and Point, to represent a cell in grid with 
 * live/dead state and a point to represent any grid cell.
 * - Pattern is a helper class, to translate a shorthand 
 * notation of a pattern of a rectangular grid into a set of 
 * live points. We got a bunch of test patterns from wikipedia.
 */

import java.util.HashMap;

// optional CL args: [ <pattern name> [ <max ticks> ]
public class ChargepointDemo {
	private static final HashMap<String, String> patternDict = new HashMap<String,String>() {
		private static final long serialVersionUID = 1L;
		{
			put("block","XX/XX");
			put("blink","XXX");
			put("bounce","XX/XX/  XX/  XX");
			put("glider"," X/  X/XXX");		// this one used for demo
			put("spaceship"," XXXX/X   X/    X/X  X");
			put("expanding","      X/    X XX/    X X/    X/  X/X X");
		}};
	public static void main(String[] args) {
		// key game parameters
		final int[] grid_size = new int[] {10,10};
		final int[] grid_margins = new int[] {2,2,2,2};
		final int tickIntervalMillis = 1000;
		final String pattern = args.length > 0 ? args[0].toLowerCase() : "glider";
		final int maxTicks = args.length > 1 ? Integer.parseInt(args[1]) : 60;
		System.out.println("hello, chargepoint!\nWelcome to Game of Life... playing '" + pattern + "'");
		System.out.println("will run " + maxTicks + " ticks, one every " + tickIntervalMillis + " msec");
		// committing you to 60 seconds of entertainment...
		final String htmlFileout = String.format("html:gameoflife_%s.html", pattern);
		GameOfLife gameboard = new GameOfLife(grid_size, patternDict.get(pattern), grid_margins);
		gameboard.run(tickIntervalMillis, maxTicks, htmlFileout);
//		gameboard.run(tickIntervalMillis, maxTicks, "console");
		System.out.println("Game Over... good bye!");
	}
}
