package chargepointDemo;

/*
 * Point is used to communicate transitions in the state of a grid cells
 */
public class GridPoint {
	private int row=0,col=0;
	private GridCell state;

	public GridPoint(int row, int col) {
		this.row = row;
		this.col = col;
		this.state = new GridCell();
	}

	public GridPoint(int row, int col, boolean isAlive) {
		this.row = row;
		this.col = col;
		this.state = new GridCell(isAlive);
	}

	// plain vanilla access/mutate methods
	
	public boolean isAlive() {
		return this.state.isAlive();
	}
	
	public int row() { 
		return this.row; 
	}

	public int col() { 
		return this.col; 
	}

	public void moveTo(int[] newOrigin) {
		this.row += newOrigin[0];
		this.col += newOrigin[1];
	}
	
	@Override
	public String toString() {
		return String.format("(%d,%d,%s)", 
				this.row(), this.col(), 
				this.isAlive() ? "alive" : "dead");
	}
}
