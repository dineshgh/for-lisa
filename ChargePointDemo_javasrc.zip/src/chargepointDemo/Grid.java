package chargepointDemo;

/*
 * Grid - a grid to hold the cells
 * (other grid types - fixed, wrap (horiz/vert), ...)
 * 
 * A grid is a 2d rectangular arrangement of cells. Sometimes we'll
 * use N-S and E-W instead of top-bottom and right-left directions.
 * Grid origin is in top-left corner.
 * 
 * We implement our grid as an ArrayList of rows,
 * where a row is an ArrayList of Cells.
 *
 * To simplify our calculations, we are going to ensure our
 * grid has a padding of dead rows/columns. Specified as margin
 * (CSS-style!). Any time the grid is updated, the margins are
 * checked and maintained
 */

import java.util.*;
import java.util.stream.IntStream;

public class Grid {
	private enum Neighbors {
		// A cell has 8 neighbors
		// specified by grid coordinate (row-column) offsets
		W(-1,0), E(1,0), S(0,1), N(0,-1), NE(-1,1), SE(1,1), SW(1,-1), NW(-1,-1);
		public final int dRow;
		public final int dCol;
		private Neighbors(int dRow, int dCol) {
			this.dRow = dRow;
			this.dCol = dCol;
		}
	}
	
	private int[] extent = {0,0};		// Rows, Columns
	private int[] margins = {1,1,1,1}; 	// top right bottom left (like CSS)
	private ArrayList<ArrayList<GridCell>> rows;
	
	
	// Grid - construct a simple rectangular grid
	// @type - type name (inf, fixed, etc.) Only inf is implemented
	// @size - [row,col] counts of initial grid
	// @initialPattern - initial pattern and location
	// patternLocation - where to apply the pattern (only "center" allowed)
	public Grid(String type, int[] initialSize, int[] margins, 
			Pattern initialPattern, String patternLocation) {
		// ensure parameters are ok
		if (type != "inf" || patternLocation != "center") {
			throw new RuntimeException(String.format("bad inputs - unknown grid type '%s' or location '%s'",  type, patternLocation));
		}
		// enforce a minimum margin
		for (int i = 0; i < margins.length; ++i) {
			if (margins[i] < 1) {
				throw new RuntimeException(String.format("bad inputs - margins insufficient %s",  margins));
			}
		}
		// create & initialize the grid
		// we are going to realize every cell of the grid up-front, making it concerete
		this.extent = initialSize.clone();
		this.margins = margins.clone(); // assume it's OK
		this._createEmptyGrid();
		// at this point, we have a grid of Cells, all dead of course. turn on chosen points
		this._setInitialPattern(initialPattern, patternLocation);
		this._ensureMargins(false);
	}

	
	// simple accessors, quick and dirty
	
	public boolean isAlive(int rownum, int colnum) {
		return this.rows.get(rownum).get(colnum).isAlive();
	}
	
	
	public int[] getExtent() {
		return this.extent.clone();
	}
	
	
	
	public ArrayList<GridCell> getRow(int rownum) {
		return this.rows.get(rownum);
	}
	
	
	// count live neighbors by row
	// rownum can range from -1 (one above) to size (one below)
	// the result size matches grid size because no new corners can come alive in a tick
	
	public int[] countLivingNeighbors(int rownum) {
		int[] res = new int[this.extent[1]];
		for (int colnum = 0; colnum < this.extent[1]; ++colnum) {
			res[colnum] = this.countLivingNeighbors(rownum, colnum);
		}
		return res;
	}
	
	
	
	public int countLivingNeighbors(int rownum, int colnum) {
		int count = 0;
		for (Neighbors whichway : Neighbors.values()) {
			GridCell cell = this._getCell(rownum + whichway.dRow, colnum + whichway.dCol);
			count += (cell != null && cell.isAlive()) ? 1 : 0;
		}
		return count;
	}
	
	
	
	// applyTransitions - deaths and births
	// 
	// @points	list of transitions (ie deaths and births)
	// @trimNow whether to trim away excessive margins now or not
	public void applyTransitions(List<GridPoint> points, boolean trimNow) {
		// update
		for (GridPoint x : points) {
			this.rows.get(x.row()).get(x.col()).set(x.isAlive());
		}
		// margin check
		this._ensureMargins(trimNow);
	}


	
	// create an empty grid per extte\e nt
	private void _createEmptyGrid() {
		// we are going to realize every cell of the grid up-front, making it concerete
		this.rows = new ArrayList<ArrayList<GridCell>>(this.extent[0]);
		for (int i = 0; i < this.extent[1]; ++i) {
			this._addARow(0);
		}
	}
	
	
	
	// insert an empty row 
	private void _addARow(int at) {
		ArrayList<GridCell> a_row = new ArrayList<GridCell>(this.extent[1]);
		for (int j = 0; j < this.extent[1]; ++j)
			a_row.add(j, new GridCell());
		this.rows.add(at, a_row);
	}
	
	
	
	// insert an empty column
	private void _addAColumn(int at) {
		IntStream.range(0, this.rows.size())
			.forEach( rownum -> this.rows.get(rownum).add(at, new GridCell()));
	}
	
	
	
	// trim a row
	// suppress trim if you want to see the grid expand
	private void _trimARow(int where) {
//		System.out.println("--trimming a row-- at " + where + ",  num rows = " + this.rows.size());
		this.rows.remove(where);
	}
	
	
	
	// trim a column
	private void _trimAColumn(int where) {
//		System.out.println("--trimming a column-- at " + where + ",  num cols = " + this.rows.get(0).size());
		IntStream.range(0, this.rows.size())
			.forEach( rownum -> this.rows.get(rownum).remove(where));
	}

	
	
	// initialize the grid with a given seed pattern at a targeted origin
	// @p 		pattern to use
	// @where 	location of the pattern (only "center" supported)
	private void _setInitialPattern(Pattern p, String where) {
		// locate the top-left corner to translate given pattern points
		int[] pextent = p.getExtent();
		int r0 = (int)Math.floor((this.extent[0] - pextent[0])/2);
		int c0 = (int)Math.floor((this.extent[1] - pextent[1])/2);
//		p.moveTo(new int[] {r0,c0});
//		System.out.println("set initial pattern:\n" + p);
		// set those points in the pattern, translated by [r0,c0]
		for (GridPoint x : p.getPoints()) {
			this.rows
				.get(r0 + x.row())
				.get(c0 + x.col())
				.set(x.isAlive());
		}
	}


	
	// _TrimCandidacyTester - private little class for dead row/column test
	// @grid - the grid that contains the cells to check
	private class _TrimCandidacyTester {
		private Grid g = null;
		public _TrimCandidacyTester(final Grid g) {
			this.g = g;
		}
		// test if a row comprises only of dead cells - trim candidate
		public boolean rowIsDead(int rowindex) {
			boolean dead = true;
			if (rowindex >= 0 && rowindex < this.g.extent[0] && this.g.rows.size() > 0) {
				ArrayList<GridCell> row = this.g.rows.get(rowindex);
				Optional<GridCell> foo = row.stream()
						.filter(x -> x.isAlive())
						.findFirst();
				dead = ! foo.isPresent();
			}
			return dead;
		}
		// test if a column comprises only of dead cells - trim candidate
		public boolean columnIsDead(int colindex) {
			boolean dead = true;
			// an empty row means
			if (colindex >= 0 && colindex < this.g.extent[1] && this.g.rows.size() > 0) {
				OptionalInt foo = IntStream.range(0, this.g.extent[0]) // we need these indices
				         .filter(rownum -> this.g.isAlive(rownum,colindex))
				         .findFirst();
				dead = ! foo.isPresent();
			}
			return dead;
		}
	}
	
	
	
	// ensure that margins are met in dead rows/columns at extremes
	// 1. computes dead rows and columns
	// 2. computes gap between desired and observed
	// 3. add or remove rows/columns as needed
	//
	// @trimNow whether to trim away excessive margin in this round
	//
	// to help see the transitions visually, let's do the trimming
	// only once every 5 ticks. Otherwise we might be entering some rabbithole
	
//	private void _ensureMargins(boolean do_trim) {
	public void _ensureMargins(boolean trimNow) {
		// 1. compute current "dead" rows and columns at ends
		// check first rows, then columns. because our grid repr is row-major
		int top = 0, bottom = this.extent[0] - 1; // index where first live row
		int left = 0, right = this.extent[1] - 1; // index where first live column
		_TrimCandidacyTester tester = new _TrimCandidacyTester(this);
		while (top < this.extent[0] && tester.rowIsDead(top))
			++top;
		while (bottom < this.extent[0] && bottom > top && tester.rowIsDead(bottom))
			--bottom;
		while (left < this.extent[1] && tester.columnIsDead(left))
			++left;
		while (right < this.extent[1] && right > left && tester.columnIsDead(right))
			--right;
		// 2. what's the action needed? IOW gap(observed,desired)
		// (switching terms from top bottom to N S etc to reduce clutter)
		// a. we may need to add some rows on South, and  North
		// b. we may need to add some columns on East, and  West
		// if the diff is positive, we need to top up by adding 
		// if the diff is negative, we need to trim
		int deficit_N = this.margins[0] - top;
		int deficit_E = this.margins[1] - (this.extent[1] - right - 1);
		int deficit_S = this.margins[2] - (this.extent[0] - bottom - 1);
		int deficit_W = this.margins[3] - left;
//		System.out.println(String.format("deficit/surfeit - [%d,%d,%d,%d]", deficit_N, deficit_E, deficit_S, deficit_W));
		// Rows -- address deficit or surfeit rows at North end
		for (int i = 0; i < Math.abs(deficit_N); ++i) {
			if (deficit_N > 0)
				this._addARow(0);
			else if (trimNow)
				this._trimARow(0); 
		}
		this.extent[0] = this.rows.size();
		// and, south end
		for (int i = 0; i < Math.abs(deficit_S); ++i) {
			if (deficit_S > 0)
				this._addARow(this.rows.size());
			else if (trimNow)
				this._trimARow(this.rows.size()-1); 
		}
		this.extent[0] = this.rows.size();
		// Columns -- address deficit or surfeit columns at West end
		for (int i = 0; i < Math.abs(deficit_W); ++i) {
			if (deficit_W > 0)
				this._addAColumn(0);
			else if (trimNow)
				this._trimAColumn(0);
		}
		this.extent[1] = this.rows.get(0).size();
		for (int i = 0; i < Math.abs(deficit_E); ++i) {
			if (deficit_E > 0)
				this._addAColumn(this.extent[1]);
			else if (trimNow)
				this._trimAColumn(this.extent[1] - 1); 
			this.extent[1] = this.rows.get(0).size(); // update every trim
		}
	}
	

	
	// given cell coordinates (0-relative, but can be outside bounds)
	// returns null if coordinates out of bounds
	private GridCell _getCell(int r, int c) {
		try {
			return this.rows.get(r).get(c);
		} catch (Exception e) {
			return null;
		}
	}
}
