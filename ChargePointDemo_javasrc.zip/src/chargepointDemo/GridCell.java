package chargepointDemo;

/*
 * A totally trivial representation of a cell in the game grid.
 * Game Grid is made up of rows and rows of cells.
 * A cell has a state of being alive or dead.
 */
public class GridCell {
	private boolean alive = false;
	
	public GridCell() {
		this.alive = false;
	}

	public GridCell(boolean alive) {
		this.alive = alive;
	}
	
	static
	public GridCell fromChar(char c) {
		return new GridCell(c != '.' && c != ' ');
	}
	

	// plain vanilla accesors and mutators
	

	public boolean isAlive() {
		return this.alive;
	}
	

	public void set(boolean alive) {
		this.alive = alive;
	}
	
	
	public char toChar() {
		return this.alive ? 'X' : '.';
	}
	

	// this is simply on a hunch. Maybe it will not be sufficient
	public String toHTML() {
		return "&nbsp;";
//		return String.format("<td class=\"%s\">&nbsp;</td>", this.isAlive() ? ".cell-alive" : ".cell-dead");
	}
}
