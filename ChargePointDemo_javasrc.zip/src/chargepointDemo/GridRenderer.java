package chargepointDemo;

import java.util.ArrayList;

public class GridRenderer {
	private String mode = "console";
	private Grid g = null;
	public GridRenderer(String mode, Grid g) {
		this.mode = mode;
		this.g = g;
	}
	public String render(final Grid g) {
		if (this.mode == "console") {
			return this.renderToConsole();
		}
		return "";
	}

	// print the grid as HTML
	// really, want a GridRenderer class
	public String renderToHTML(String extraHead, String extraBody) {
		int[] extent = this.g.getExtent();
		ArrayList<String> frags = new ArrayList<String>();
		frags.add("<!DOCTYPE html>\n" +
				"<html>\n" +
				"<head>\n" +
				"<style>\n" +
				"table, th, td {�border: 1px solid black; }\n" +
				"table { \n" +
				"��table-layout: fixed ;\n" +
				"��width: 100% ;\n" +
				"}\n" +
				"td { min-width: 20px; }\n" + 
				".cell-dead { background-color: lightgray; }\n" +
				".cell-alive { background-color: green; } \n" +
				"</style>\n" +
				extraHead +
				"</head>\n" +
				"<body>");
		// button to force refresh
		if (extraBody != "") {
			frags.add("<hr/>" + extraBody + "<hr/>");
		}
		frags.add("<button onClick=\"window.location.href=window.location.href\">Refresh Page</button><table rows=\"8\" cols=\"11\">\r\n");
		frags.add("<hr/>");
		frags.add(String.format("<table rows=\"%d\" cols=\"%d\">", extent[0] + 1, extent[1] + 1));
		// a header row with col#
		{
			frags.add(String.format("  <tr>"));
			frags.add(String.format("    <th>-</th>"));
			for (int colnum = 0; colnum < extent[1]; ++colnum) {
				frags.add(String.format("    <th>%d</th>", (1+colnum) % 10));
			}
			frags.add(String.format("  </tr>"));
		}
		// grid rows
		for (int rownum = 0; rownum < extent[0]; ++rownum) {
			//print a row
			ArrayList<GridCell> row = this.g.getRow(rownum);
			frags.add(String.format("  <tr rownum=\"%d\">", rownum+1));
			for (int colnum = 0; colnum < row.size(); ++colnum) {
				if (colnum == 0)
					frags.add(String.format("    <th>%d</th>", rownum+1)); 
				//print a cell
				GridCell cell = row.get(colnum);
				frags.add(String.format("    <td colnum=\"%d\" class=\"%s\">%s</td>", 
						colnum, 
						cell.isAlive() ? "cell-alive" : "cell-dead", 
						cell.toHTML()));
			}
			frags.add(String.format("  </tr>"));
		}
		frags.add("</table>");
		frags.add("</body></html>");
		return String.join("\n", frags);
	}

	
	
	// print the grid to console as text
	public String renderToConsole() {
		ArrayList<String> frags = new ArrayList<String>();
		int[] extent = this.g.getExtent();
		for (int i = 0; i < extent[1]; i = i + 10)
			frags.add("123456789-");
		String header_row = String.join("",  frags).substring(0, extent[1]);
		frags.clear();
		frags.add(header_row);
		for (int rownum = 0; rownum < extent[0]; ++rownum) {
			//print a row
			ArrayList<GridCell> row = this.g.getRow(rownum);
			StringBuilder sb = new StringBuilder();
			for (int colnum = 0; colnum < row.size(); ++colnum) {
				//print a cell
				sb.append(row.get(colnum).toChar());
			}
			frags.add(sb.toString());
		}
		return String.join("\n", frags);
	}

}
