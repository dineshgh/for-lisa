package chargepointDemo;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/*
 * GameOfLife - a 0-player board game, played by a ticker. And
 * indeed a play is called a "tick" which applies some update rules.
 * 
 * A GOL game needs a few things to get started:
 * - grid type
 * - grid initial size
 * - grid initial pattern
 *
 * Our GOL can output grid state tick by tick on console or in an HTML file
 */

import java.util.*;

import java.io.File;
import java.io.FileWriter;

public class GameOfLife {
	private Grid g = null;
	private int tickCounter = 0;
	
	// GameOfLife - orchestrates the GOL board
	// @gridType - only "inf" type is supported for now
	// @gridSize - [row, col] counts to start with
	// @patternSpec - a standardized pattern spec (can use a registry?)
	// @margins - [top,right,bottom,left] protective MINIMUM 
	//				empty rows/columns to be maintained around live cells
	public GameOfLife(int[] gridSize, String patternSpec, int[] margins) {
		System.out.println(String.format("\n+++ NEW GOL +++ pattern '%s', gridsize %s", patternSpec, Arrays.toString(gridSize)));
		this._setupGrid("inf", gridSize, margins, patternSpec, "center");
	}

	
	
	// a standardized run
	// @tickInterval	in seconds. must be positive (if <= 0, why bother with run??)
	// @maxTicks		stop after these many ticks
	// @renderTo		use "console" to print on console after every tick OR
	//						"html:filename" to print an html file (updated every tick) 
	public void run(int tickIntervalMillis, int maxTicks, String renderTo) {
		if (tickIntervalMillis <= 0 || maxTicks <= 0) {
			return;
		}
		String renderDest = "";
		File fileout = null;
		if (renderTo.startsWith("html:")) {
			String parts[] = renderTo.split(":", 2);
			renderDest = "htmlfile";
            fileout = new File(parts[1]);
			System.out.println("Will render grid to : " + fileout.getAbsolutePath());
		} else if (renderTo == "console") {
			renderDest = "console";
			System.out.println("Will render grid to : console");
		}
		// now the main gig 
		// - tick, show new state, sleep, repeat
		GridRenderer gr = new GridRenderer(renderDest, this.g);
		for (int t = 0; t < maxTicks; ++t) {
			++this.tickCounter;
			System.out.println(String.format("%s tickCounter %d", this._timestamp(), this.tickCounter));
//			System.out.println(String.format("%s memory %d", this._timestamp(), this._memoryUsed()));
			this.tick();
			if (renderDest == "console") {
				this._renderGridToConsole(gr);
			}
			else if (renderDest == "htmlfile") {
				this._renderGridToHTML(gr, fileout, tickIntervalMillis);
			}
			try {
				Thread.sleep(tickIntervalMillis);
			} catch (InterruptedException e) {
				System.out.println("run was interrupted after " + t + " ticks. NBD.");
			}
		}
	}
	
	
		
	// tick - advances game one round of births and deaths 
	// 
	// We have chosen a Grid implementation that would maintain a "protective margin" of dead rows/columns.
	// The payoff comes in simplified computations. Also we will update the grid in situ.
	//
	// 1. calculate living neighbors row by row. gather births and deaths for row as per rules
	// 2. apply the births and deaths
	// 
	// Grid will ensure the margins are maintained. This step ought to be idempotent. 
	public void tick() {
		int[] grid_extent = this.g.getExtent();
		// compute the transitions
		ArrayList<GridPoint> transitions = new ArrayList<GridPoint>();
		for( int rownum = 0; rownum < grid_extent[0]; ++rownum) {
			int[] neighbors = this.g.countLivingNeighbors(rownum);
			List<GridPoint> census = this._calcBirthsAndDeaths(rownum, neighbors);
			if (census.size()>0) {
				transitions.addAll(census);
			}
		}
		this.g.applyTransitions(transitions, this.tickCounter % 5 == 0);
	}
	

	
	// simply print the grid using "X" and "."
	private void _renderGridToConsole(GridRenderer gr) {
		String s = gr.renderToConsole(); // this.g.toConsole();
		System.out.println(s);
	}

	
	
	// print the grid to an HTML file
	// - file has a click to refresh button
	// - it has a script to autorefresh every specified seconds
	private void _renderGridToHTML(GridRenderer gr, File file, int refreshIntervalMillis) {
		String extraBody = String.format("Applied tick# %d, current time is: %s",
										this.tickCounter, this._timestamp());
		String extraHead = "<script>\n" +
					String.format("setTimeout(function(){window.location.reload(1); }, %d);\n", refreshIntervalMillis) +
			    	"</script>\n";					
		String html = gr.renderToHTML(extraHead, extraBody); // this.g.toHTML(extraHead, extraBody);
		try {
			FileWriter f = new FileWriter(file);
			f.write(html);
			f.close();
		} catch (Exception e) {
			System.out.println("file write error: " + e);
		}
	}
	
	
	
	// creates and initializes the game grid
	private void _setupGrid(String gridType, int[] gridSize, int[] margins, String patternSpecs, String patternLocation) {
		// parse the pattern and zap it on our grid
		Pattern p = new Pattern(patternSpecs);
		System.out.println("INITIAL PATTERN >>>\n" + p);

		// create a simple grid. 
		// We tweak grid size to ensure that it can hold our desired seed pattern
		// maintaining margins is not our responsibility - that goes to the Grid
		int[] pextent = p.getExtent();
		gridSize[0] = Math.max(gridSize[0],  pextent[0]); // row count
		gridSize[1] = Math.max(gridSize[1],  pextent[1]); // col count
		this.g = new Grid(gridType, gridSize, margins, p, patternLocation);
		// debug
		System.out.println("INITIAL GRID >>>");
		this._renderGridToConsole(new GridRenderer("console", this.g));
	}
	
	
	
	// Calculate births/deaths based on live neighbor counts. Our simplified rules are:
	//	a. a cell with < 2 or > 3 living neighbors will be dead in next gen
	//	b. a cell with 3 living neighbors will be alive in the next gen
	//	c. a cell with 2 or 3 living neighbors will continue to live in next gen. IOW, no change.
	private List<GridPoint> _calcBirthsAndDeaths(int rownum, final int[] neighbors) {
		ArrayList<GridPoint> census = new ArrayList<GridPoint>(neighbors.length);
		for (int colnum = 0; colnum < neighbors.length; ++colnum) {
			if (neighbors[colnum] < 2 || neighbors[colnum] > 3) {
				if (this.g.isAlive(rownum, colnum))
					census.add(new GridPoint(rownum, colnum, false));
			}
			else if (neighbors[colnum] == 3) {
				census.add(new GridPoint(rownum, colnum, true));
			}
		}
		return census;
	}
	
	
	//  debug helpers
	
	private String _timestamp() {
		DateTimeFormatter fmt = DateTimeFormatter.ofPattern("hh:mm:ss.SSS");
		return fmt.format(LocalTime.now());
	}
	
	private long _memoryUsed() {
	    Runtime runtime = Runtime.getRuntime();
	    runtime.gc();
	    long memory = runtime.totalMemory() - runtime.freeMemory();
	    return (memory / 1024);
	}
}
