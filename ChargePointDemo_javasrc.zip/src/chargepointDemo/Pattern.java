package chargepointDemo;

/*
 * Pattern - encapsulates the grid state in a rectangular block
 * of X's and '.'s - X for cells that are alive and . for dead ones.
 * Here we are using Pattern trivially to manage the initial / seed pattern.
 * 
 * (Taking inspiration from chess board specs) 
 * A Pattern is specified as a set of row specs, joined by "/".
 * Within a "row", blank or "." signify a dead cell; otherwise alive.
 * Leading and trailing "/" are useless, but intermittent "//" matter
 * and are needed to inject in-between dead rows.
 * No pattern spec is invalid.
 * 
 * FYI: input rows can be jagged, but the pattern interpretation is
 * rectangular.
 *
 * E.g., "X  X" means a row-vector 1x4 with column 1,4 are alive, 2,3 are dead.
 * E.g., "X Z//  X " means a matrix 3x4, with blank middle row
 * E.g., "X.Z/.../..X" same as preceding
 * 
 * Internally, we convert the pattern into a set of points that are alive.
 */

import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.List;
import java.util.ArrayList;

public class Pattern {
	static private String rs = "/"; // row separator
	private int[] extent = {0,0}; // that rectangular point of view
	private ArrayList<GridPoint> points = new ArrayList<GridPoint>();
	
	public Pattern() {}
	
	// more useful constructor
	// @pattern - pattern specification as described above
	public Pattern(String pattern) {
		// ignore all  "/" at ends - these are superfluous
		String clean_pattern = pattern.replaceAll("(^/+)|(/+$)", "");
		this.points = this._parsePattern(clean_pattern);
		this.extent = this._determineExtent(this.points);
	}


	// quick and dirty accessors
	public ArrayList<GridPoint> getPoints() {
		return this.points;
	}
	public int[] getExtent() {
		return this.extent.clone();
	}
	
	
	// returns to an original style spec but
	// in a full rectangular format
	//
	// NB: Maybe useful in printing even a Grid - perhaps
	@Override
	public String toString() {
		final char DEADCELL = ' ';
		final char LIVECELL = 'X';
		// GIVEN: a bunch of Point objects in a grid format
		// OUTPUT: a visual grid, of spaces/dots and X's.
		String[] rows = new String[this.extent[0]];	// we already know the count of rows
		char[] row = new char[this.extent[1]];
		GridPoint prev_point = null;
		// we will initialize row to blanks
		// fill one row, and populate rows array.
		// remember to collect the last row too
		for (int i = 0; i < row.length; ++i ) {
			row[i] = DEADCELL;
		}
		for (GridPoint p : this.points) {
			if (prev_point != null && p.row() != prev_point.row()) {
				// we were building a row. we just completed that.
				rows[prev_point.row()] = new String(row);
				for (int i = 0; i < row.length; ++i ) 
					row[i] = DEADCELL;
				// are there any blank rows in-between?
				// inject a copy of the newly minted blank
				for (int i = prev_point.row() + 1; i < p.row(); ++i )
					rows[i] = new String(row);
			}
			prev_point = p;
			row[p.col()] = LIVECELL; // print a fill
		}
		rows[prev_point.row()] = new String(row);
		return String.format("extent [%d,%d] '%s'", 
				this.extent[0], this.extent[1], String.join(Pattern.rs, rows) );
	}
	
	
	public void moveTo(int[] newOrigin) {
		for (GridPoint p : this.points)
			p.moveTo(newOrigin);
	}

	// translates specification into a set of live points
	private ArrayList<GridPoint> _parsePattern(String pattern) {
		ArrayList<GridPoint> points = new ArrayList<GridPoint>();
		String[] rows = pattern.split(Pattern.rs, -1);
		int rownum = 0;
		for (String z : rows) {
			List<GridPoint> temp = this._parseOneRow(z, rownum);
			points.addAll(temp);
			++rownum;
		}
		return points;
	}
	
	
	
	// convert one row of live/dead cell specs into set of alive points.
	// dead points are ignored.
	private List<GridPoint> _parseOneRow(String z, final int rownum) {
		char[] zchars = z.toCharArray();
		List<GridPoint> x = IntStream.range(0, z.length()) // we need the indices
				 // filter out dead cells
		         .filter(colnum -> GridCell.fromChar(zchars[colnum]).isAlive())
		         .mapToObj(colnum -> new GridPoint(rownum, colnum, true))
		         .collect(Collectors.toList());
		return x;
	}

	

	// for given set of points, get its RxC rectangle size 
	private int[] _determineExtent(List<GridPoint> points) {
		int R = 0, C = 0;
		for (GridPoint p : points) {
			// nb: point's r/c are 0-relative; we want counts here
			R = Math.max(R, p.row() + 1);
			C = Math.max(C, p.col() + 1);
		}
		return new int[] {R,C};
	}

}
